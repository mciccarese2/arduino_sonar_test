This is the old giCentreUtils library V.3.3, which is compatible with Processing 2.x or older. Users are strongly advised to migrate to Processing 3 and giCentreUtils V.3.4 or newer.

If you have to use Processing 2, you should rename library/gicentreUtils.jar to gicentreUtils3_4.jar and then move the file gicentreUtils3_3.jar from this folder into the library folder renaming it to gicentreUtils.jar

You can check the version of giCentreUtils currently installed by calling Version.getVersion() or Version.getVersionText().

Jo Wood, giCentre, 6th February, 2016.