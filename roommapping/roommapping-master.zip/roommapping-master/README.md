roommapping
===========

3D Room Mapping Arduino Robot

This is the code that was utilized to create a 3D room mapping robot that utilized SLAM methodologies to return a 3D map of a robot's surrounding area. Here you can find all the code that was used algorithimically as well as the mechanical instructions for the robot to perform its tasks. 
